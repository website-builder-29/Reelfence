# ReelFence (Android starter project)

ReelFence is a small on-device Android AccessibilityService prototype intended to block the Instagram Reels tab while leaving normal Instagram navigation available.

## Important limitations
- This is source code, not a prebuilt APK.
- The prototype blocks only when it can identify Instagram's main bottom navigation and a selected Reels item.
- A Reel opened from a DM is expected to be full-screen and therefore allowed. Instagram's interface changes often, so this needs testing on the current Instagram version.
- It does **not** reliably stop swiping from a DM-opened Reel to the next Reel. Instagram does not expose a stable public API that identifies the origin of every Reel screen. Do not treat this as a guaranteed DM-only viewer.
- Accessibility permission is powerful. This app uses it only to inspect visible UI labels locally; it does not transmit or store screen content.

## Build
Open this folder in Android Studio and build the `app` debug APK, or push it to a GitHub repository and run the included Actions workflow. The resulting artifact is `app-debug.apk`.

## Install and enable
Install the debug APK, open ReelFence, tap **Open Accessibility Settings**, then enable **ReelFence Instagram filter**. Test:
1. Open Instagram and tap the Reels tab — the blocker should appear if Instagram exposes the expected selected navigation label.
2. Open a friend-shared Reel from a DM — it should remain viewable if it opens without the main bottom navigation.
3. If detection is wrong, disable the accessibility service in Android Settings.

This is an experimental personal-use prototype, not affiliated with Instagram or Meta.
