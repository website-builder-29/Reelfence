package com.reelfence

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class ReelFenceService : AccessibilityService() {
    private var blocker: LinearLayout? = null
    private var windowManager: WindowManager? = null
    private var showing = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != INSTAGRAM_PACKAGE) {
            hideBlocker()
            return
        }
        val root = rootInActiveWindow ?: return
        val labels = mutableListOf<Pair<String, Boolean>>()
        collectLabels(root, labels)
        val hasBottomNav = labels.any { it.first.contains("home", true) } &&
            labels.any { it.first.contains("search", true) } &&
            labels.any { it.first.contains("profile", true) }
        val reelsSelected = labels.any {
            it.first.contains("reel", true) && it.second
        }
        // Conservative rule: only block when Instagram exposes its main bottom navigation
        // and marks the Reels destination as selected. Full-screen DM-shared reels are not blocked.
        if (hasBottomNav && reelsSelected) showBlocker() else hideBlocker()
    }

    private fun collectLabels(node: AccessibilityNodeInfo, out: MutableList<Pair<String, Boolean>>) {
        val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
            .joinToString(" ").trim()
        if (label.isNotEmpty()) out.add(label to node.isSelected)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectLabels(child, out)
                child.recycle()
            }
        }
    }

    private fun showBlocker() {
        if (showing) return
        val wm = windowManager ?: return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            setBackgroundColor(0xFF111827.toInt())
        }
        panel.addView(TextView(this).apply {
            text = "Reels feed blocked"
            textSize = 27f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        panel.addView(TextView(this).apply {
            text = "You can still open a Reel a friend sends in a DM. Return to your messages instead of entering the Reels feed."
            textSize = 17f
            setTextColor(0xFFE5E7EB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 26)
        })
        panel.addView(Button(this).apply {
            text = "Go back"
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_BACK); hideBlocker() }
        })
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(panel, params)
        blocker = panel
        showing = true
    }

    private fun hideBlocker() {
        if (!showing) return
        try { blocker?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        blocker = null
        showing = false
    }

    override fun onInterrupt() { hideBlocker() }
    override fun onDestroy() { hideBlocker(); super.onDestroy() }

    companion object { private const val INSTAGRAM_PACKAGE = "com.instagram.android" }
}
