package com.reelfence

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "ReelFence"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "Keep Instagram DMs, stories and posts. Put a fence around the Reels tab. Reels opened from a friend's DM should remain viewable when Instagram opens them without its main bottom navigation."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val status = TextView(this).apply {
            text = "Setup required: enable ReelFence in Android Accessibility settings."
            textSize = 15f
            gravity = Gravity.CENTER
        }
        val settings = Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "\nHow it works: ReelFence checks the visible Instagram navigation labels on-device. When it detects the selected Reels tab, it displays a blocking screen. No Instagram login, message contents, or internet access is used. Instagram updates may change its labels and affect detection."
            textSize = 13f
            setPadding(0, 20, 0, 0)
        }
        layout.addView(title)
        layout.addView(intro)
        layout.addView(status)
        layout.addView(settings)
        layout.addView(note)
        setContentView(layout)
    }
}
